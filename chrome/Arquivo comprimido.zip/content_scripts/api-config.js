const apiConfig = {
  endpoint: 'https://omelete-tabs-api.vercel.app/api/news',
}